﻿using System;
using System.Collections.Generic;
using System.Text;

namespace hw15
{
    class powerRangers
    {
        public string _name { get; set; }
        public string _color { get; set; }
        public int _abilityLevel { get; set; }
        public string _ability { get; set; }

        public powerRangers(string name, string color, int abilityLevel, string ability)
        {
            _name = name;
            _color = color;
            _abilityLevel = abilityLevel;
            _ability = ability;
        }
    }
}
        



    
